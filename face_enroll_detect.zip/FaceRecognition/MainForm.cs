﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.IO;
using System.Diagnostics;
using MySql.Data.MySqlClient;
using System.Data;

using System.IO.Ports;


using FaceRecognition;

namespace FaceRecognition
{
    public partial class FaceDetect : Form
    { 

        public string SQL, fileNameimg, comportno, numberOfFaceDetected, empStat, countInOut;
        System.IO.Ports.SerialPort SerialPort1 = new System.IO.Ports.SerialPort();

        //Declararation of all variables, vectors and haarcascades
        Image<Bgr, Byte> currentFrame;
        Capture grabber;
        HaarCascade face;
        HaarCascade eye;
        MCvFont font = new MCvFont(FONT.CV_FONT_HERSHEY_TRIPLEX, 0.5d, 0.5d);
        Image<Gray, byte> result, TrainedFace = null;
        Image<Gray, byte> gray = null;
        List<Image<Gray, byte>> trainingImages = new List<Image<Gray, byte>>();
        List<string> labels= new List<string>();
        List<string> NamePersons = new List<string>();
        int ContTrain, NumLabels, t;
        string name, names = null;




        #region Connection And Setting up connection
        public MySqlDataAdapter da;
        public MySqlDataReader dr;
        public MySqlCommand cmd;

 
        #endregion

        public FaceDetect()
        {
            InitializeComponent();
            face = new HaarCascade("haarcascade_frontalface_default.xml");
            try
            {
                //Load of previus trainned faces and labels for each image
                string Labelsinfo = File.ReadAllText(Application.StartupPath + "/TrainedFaces/TrainedLabels.txt");
                string[] Labels = Labelsinfo.Split('%');
                NumLabels = Convert.ToInt16(Labels[0]);
                ContTrain = NumLabels;
                string LoadFaces;

                for (int tf = 1; tf < NumLabels+1; tf++)
                {
                    LoadFaces = "face" + tf + ".bmp";
                    trainingImages.Add(new Image<Gray, byte>(Application.StartupPath + "/TrainedFaces/" + LoadFaces));
                    labels.Add(Labels[tf]);
                }
            
            }
            catch(Exception)
            {
                MessageBox.Show("Nothing in binary database, please add at least a face(Simply train the prototype with the Add Face Button).", "Triained faces load", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void StartCapturing()
        { 
            grabber = new Capture();
            grabber.QueryFrame();
            Application.Idle += new EventHandler(FrameGrabber);
        }

        void FrameGrabber(object sender, EventArgs e)
        {
            NamePersons.Add("");
            currentFrame = grabber.QueryFrame().Resize(320, 240, Emgu.CV.CvEnum.INTER.CV_INTER_CUBIC);


            gray = currentFrame.Convert<Gray, Byte>();      //Convert it to Grayscale
                    MCvAvgComp[][] facesDetected = gray.DetectHaarCascade(  //Face Detector
                  face,
                  1.2,
                  10,
                  Emgu.CV.CvEnum.HAAR_DETECTION_TYPE.DO_CANNY_PRUNING,
                  new Size(20, 20));

                    //Action for each element detected
                    foreach (MCvAvgComp f in facesDetected[0])
                    {
                        t = t + 1;
                        result = currentFrame.Copy(f.rect).Convert<Gray, byte>().Resize(100, 100, Emgu.CV.CvEnum.INTER.CV_INTER_CUBIC);
                        //draw the face detected in the 0th (gray) channel with blue color
                        currentFrame.Draw(f.rect, new Bgr(Color.Red), 2);


                        if (trainingImages.ToArray().Length != 0)
                        {
                            //TermCriteria for face recognition with numbers of trained images like maxIteration
                        MCvTermCriteria termCrit = new MCvTermCriteria(ContTrain, 0.001);

                        //Eigen face recognizer
                        EigenObjectRecognizer recognizer = new EigenObjectRecognizer(
                           trainingImages.ToArray(),
                           labels.ToArray(),
                           3000,
                           ref termCrit);

                        name = recognizer.Recognize(result);

                            //Draw the label for each face detected and recognized
                        currentFrame.Draw(name, ref font, new Point(f.rect.X - 2, f.rect.Y - 2), new Bgr(Color.LightGreen));

                        }

                            NamePersons[t-1] = name;
                            NamePersons.Add("");
                            numberOfFaceDetected = facesDetected[0].Length.ToString();
                    }
                        t = 0;

                        //Names concatenation of persons recognized
                    for (int nnn = 0; nnn < facesDetected[0].Length; nnn++)
                    {
                        names = names + NamePersons[nnn];
                    }
                    //Show the faces procesed and recognized
                    imageBoxFrameGrabber.Image = currentFrame;

                    txtregNo.Text = names;
                    lblregNo.Text = names;
                    names = "";
                    //Clear the list(vector) of names
                    NamePersons.Clear();

                }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            dgrv.BorderStyle = BorderStyle.None;
            dgrv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249);
            dgrv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgrv.DefaultCellStyle.SelectionBackColor = Color.DodgerBlue;
            dgrv.DefaultCellStyle.SelectionForeColor = Color.WhiteSmoke;
            dgrv.BackgroundColor = Color.White;
            dgrv.EnableHeadersVisualStyles = true;
            dgrv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgrv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 25, 72);
            dgrv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White; 

            timer1.Start();
            dateTimePicker7.Value = DateTime.Now;
            StartCapturing();
             
           DisplayTimeSheet();
           clr(); 
        }
         

        private void Timer3_Tick(object sender, EventArgs e)
        {
            searchUser();

        }
       
        private void searchUser()
        {
            Timer3.Stop();
           
            config.connect();
            cmd = new MySqlCommand("SELECT *,CONCAT(fname,' ' ,lname)fullname FROM tbl_students WHERE studNo=@fd1", config.con);
            cmd.Parameters.AddWithValue("@fd1", txtregNo.Text);
            dr = cmd.ExecuteReader();
            if ((dr.Read())) //Data exist
            { 
                lblregNo.Text = (dr["studNo"]).ToString();
                lblname.Text = (dr["fullname"]).ToString();
                txtId.Text = dr["id"].ToString();
                lblStatus.Text = (dr["logStatus"]).ToString();
                //AutoClosingMessageBox.Show("CLOCK IN has been successfully recorded", "Successful", 1000);  
              
                if (lblStatus.Text == "IN")
                {
                    lblStatus.Text = "OUT";
                }
                else
                {
                    lblStatus.Text = "IN";
                }

                button1.Enabled = true;
                button1.PerformClick(); 

                //byte[] result = (byte[])dr["pic"];
                //int ArraySize = result.GetUpperBound(0);
                //MemoryStream ms = new MemoryStream(result, 0, ArraySize);
                //pictureBox1.Image = Image.FromStream(ms); 
                cmd.Dispose();
                return;
            }
            else
            {
                clr(); 
            }
        } 

        void clr()
        {
            dateTimePicker7.Value = DateTime.Now;
          //  lblname.Text = "INFORMATION";
            lblregNo.Text = "ID";
            txtregNo.Text = "";
            txtregNo.Focus();
            button1.Enabled = false;
        }

      #region TimeInOut. 
        

        private void button1_Click(object sender, EventArgs e)
        {
            String inout_id  ;  
            

            config.connect();
            MySqlDataAdapter sda = new MySqlDataAdapter("INSERT INTO tbl_inout(stud_id,xdate,xtime,details,status)VALUES('" + txtId.Text + "', CURRENT_DATE(), CURRENT_TIME(),'" + lblregNo.Text + "','" + lblStatus.Text + "')", config.con);
            sda.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Successfully  '" + lblStatus.Text + "'", "Success");  
            MySqlDataAdapter sda1 = new MySqlDataAdapter("UPDATE tbl_students SET  logStatus='" + lblStatus.Text + "'  WHERE id='" + txtId.Text + "'  ", config.con);
            sda1.SelectCommand.ExecuteNonQuery(); 

              
                lblStatus.Text = button1.Text;
                
                DisplayTimeSheet();
            
        }
 

        private void DisplayTimeSheet()
        {  
            
            config.connect();
            MySqlDataAdapter sda = new MySqlDataAdapter("SELECT i.id,CONCAT(fname, ' ' ,lname)fullname,xdate,xtime  ,i.status  FROM tbl_inout i INNER JOIN tbl_students r ON r.id=i.stud_id   ORDER BY id DESC ", config.con);
            DataTable data = new DataTable();
            sda.Fill(data);
            dgrv.DataSource = data;
            dgrv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgrv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;

            dgrv.AllowUserToOrderColumns = true;
            dgrv.AllowUserToResizeColumns = true;
        }
       
        #endregion

        private void timer1_Tick(object sender, EventArgs e)
        {
            //labelTime.Text = DateTime.Now.ToLongTimeString();
            //labelDate.Text = DateTime.Now.ToLongDateString();

            lblDate.Text = DateTime.Now.ToLongDateString();
            lblTime.Text = DateTime.Now.ToString("h:mm:ss tt");
            //dtpNow.Text = DateTime.Now.ToString("h:mm:ss tt");
        }

      
       



        public class AutoClosingMessageBox
        {
            System.Threading.Timer _timeoutTimer;
            string _caption;
            AutoClosingMessageBox(string text, string caption, int timeout)
            {
                _caption = caption;
                _timeoutTimer = new System.Threading.Timer(OnTimerElapsed,
                    null, timeout, System.Threading.Timeout.Infinite);
                using (_timeoutTimer)
                    MessageBox.Show(text, caption);
            }
            public static void Show(string text, string caption, int timeout)
            {
                new AutoClosingMessageBox(text, caption, timeout);
            }
            void OnTimerElapsed(object state)
            {
                IntPtr mbWnd = FindWindow("#32770", _caption); // lpClassName is #32770 for MessageBox
                if (mbWnd != IntPtr.Zero)
                    SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                _timeoutTimer.Dispose();
            }
            const int WM_CLOSE = 0x0010;
            [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
            static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
            [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
            static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);
        }

        private void txtregNo_TextChanged(object sender, EventArgs e)
        {
          

            if (txtregNo.Text != "")
            {
                if (txtregNo.Text != "0")
                {
                    button1.Enabled = true;
                    Timer3.Start();
                }
                else
                {

                }

            }
            else
            {
                button1.Enabled = false;
                txtId.Clear();
            }
        }

 

     
   }
}