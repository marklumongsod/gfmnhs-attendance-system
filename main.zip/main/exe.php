<html> 
 <?php 
 
 echo '<script type="text/javascript">
           window.location = "http://localhost/face/exe.php"
      </script>';
      ?>
</html>