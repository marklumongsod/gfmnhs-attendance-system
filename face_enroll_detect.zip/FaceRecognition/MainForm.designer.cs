﻿namespace FaceRecognition
{
    partial class FaceDetect
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevComponents.DotNetBar.Controls.ClockStyleData clockStyleData1 = new DevComponents.DotNetBar.Controls.ClockStyleData();
            DevComponents.DotNetBar.Controls.ColorData colorData1 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ColorData colorData2 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ColorData colorData3 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ClockHandStyleData clockHandStyleData1 = new DevComponents.DotNetBar.Controls.ClockHandStyleData();
            DevComponents.DotNetBar.Controls.ColorData colorData4 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ColorData colorData5 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ClockHandStyleData clockHandStyleData2 = new DevComponents.DotNetBar.Controls.ClockHandStyleData();
            DevComponents.DotNetBar.Controls.ColorData colorData6 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ClockHandStyleData clockHandStyleData3 = new DevComponents.DotNetBar.Controls.ClockHandStyleData();
            DevComponents.DotNetBar.Controls.ColorData colorData7 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ColorData colorData8 = new DevComponents.DotNetBar.Controls.ColorData();
            this.Timer3 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgrv = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xtime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.PanelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.lblhour = new System.Windows.Forms.Label();
            this.lblday = new System.Windows.Forms.Label();
            this.lblyear = new System.Windows.Forms.Label();
            this.lblmonth = new System.Windows.Forms.Label();
            this.DateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.DateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.txtto = new System.Windows.Forms.TextBox();
            this.DateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.CheckBox2 = new System.Windows.Forms.CheckBox();
            this.txtti = new System.Windows.Forms.TextBox();
            this.DTPicker2 = new System.Windows.Forms.DateTimePicker();
            this.txtmins = new System.Windows.Forms.TextBox();
            this.txthrs = new System.Windows.Forms.TextBox();
            this.DTPicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtregNo = new System.Windows.Forms.TextBox();
            this.imageBoxFrameGrabber = new Emgu.CV.UI.ImageBox();
            this.lblregNo = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.imageBox1 = new Emgu.CV.UI.ImageBox();
            this.pic2 = new System.Windows.Forms.PictureBox();
            this.LabelX1 = new DevComponents.DotNetBar.LabelX();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.clockControl9 = new DevComponents.DotNetBar.Controls.AnalogClockControl();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageBoxFrameGrabber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).BeginInit();
            this.Panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Timer3
            // 
            this.Timer3.Interval = 800;
            this.Timer3.Tick += new System.EventHandler(this.Timer3_Tick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgrv);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(664, 621);
            this.panel1.TabIndex = 1130;
            // 
            // dgrv
            // 
            this.dgrv.AllowUserToAddRows = false;
            this.dgrv.AllowUserToOrderColumns = true;
            this.dgrv.ColumnHeadersHeight = 35;
            this.dgrv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.fullname,
            this.xdate,
            this.xtime,
            this.status});
            this.dgrv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgrv.Location = new System.Drawing.Point(0, 0);
            this.dgrv.MultiSelect = false;
            this.dgrv.Name = "dgrv";
            this.dgrv.ReadOnly = true;
            this.dgrv.RowHeadersVisible = false;
            this.dgrv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrv.ShowEditingIcon = false;
            this.dgrv.Size = new System.Drawing.Size(664, 621);
            this.dgrv.TabIndex = 2;
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            this.id.Visible = false;
            // 
            // fullname
            // 
            this.fullname.DataPropertyName = "fullname";
            this.fullname.HeaderText = "Fullname";
            this.fullname.Name = "fullname";
            this.fullname.ReadOnly = true;
            // 
            // xdate
            // 
            this.xdate.DataPropertyName = "xdate";
            this.xdate.HeaderText = "Date";
            this.xdate.Name = "xdate";
            this.xdate.ReadOnly = true;
            // 
            // xtime
            // 
            this.xtime.DataPropertyName = "xtime";
            this.xtime.HeaderText = "Time";
            this.xtime.Name = "xtime";
            this.xtime.ReadOnly = true;
            // 
            // status
            // 
            this.status.DataPropertyName = "status";
            this.status.HeaderText = "Status";
            this.status.Name = "status";
            this.status.ReadOnly = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(6, 397);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 86);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // lblStatus
            // 
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Font = new System.Drawing.Font("Calibri", 20F, System.Drawing.FontStyle.Bold);
            this.lblStatus.ForeColor = System.Drawing.Color.Black;
            this.lblStatus.Location = new System.Drawing.Point(142, 557);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(205, 55);
            this.lblStatus.TabIndex = 8;
            this.lblStatus.Text = ".....";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PanelEx1
            // 
            this.PanelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.PanelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.PanelEx1.Location = new System.Drawing.Point(25, 25);
            this.PanelEx1.Name = "PanelEx1";
            this.PanelEx1.Size = new System.Drawing.Size(515, 188);
            this.PanelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.PanelEx1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.PanelEx1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.PanelEx1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.PanelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.PanelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.PanelEx1.Style.GradientAngle = 90;
            this.PanelEx1.TabIndex = 1125;
            // 
            // lblhour
            // 
            this.lblhour.Font = new System.Drawing.Font("Calibri", 25F, System.Drawing.FontStyle.Bold);
            this.lblhour.ForeColor = System.Drawing.Color.Black;
            this.lblhour.Location = new System.Drawing.Point(6, 99);
            this.lblhour.Name = "lblhour";
            this.lblhour.Size = new System.Drawing.Size(204, 41);
            this.lblhour.TabIndex = 589;
            this.lblhour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblday
            // 
            this.lblday.Font = new System.Drawing.Font("Calibri", 25F, System.Drawing.FontStyle.Bold);
            this.lblday.ForeColor = System.Drawing.Color.Black;
            this.lblday.Location = new System.Drawing.Point(6, 49);
            this.lblday.Name = "lblday";
            this.lblday.Size = new System.Drawing.Size(204, 41);
            this.lblday.TabIndex = 588;
            this.lblday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblyear
            // 
            this.lblyear.Font = new System.Drawing.Font("Calibri", 20F, System.Drawing.FontStyle.Bold);
            this.lblyear.ForeColor = System.Drawing.Color.Black;
            this.lblyear.Location = new System.Drawing.Point(252, 143);
            this.lblyear.Name = "lblyear";
            this.lblyear.Size = new System.Drawing.Size(256, 33);
            this.lblyear.TabIndex = 587;
            this.lblyear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblmonth
            // 
            this.lblmonth.Font = new System.Drawing.Font("Calibri", 30F, System.Drawing.FontStyle.Bold);
            this.lblmonth.ForeColor = System.Drawing.Color.Black;
            this.lblmonth.Location = new System.Drawing.Point(258, 16);
            this.lblmonth.Name = "lblmonth";
            this.lblmonth.Size = new System.Drawing.Size(250, 49);
            this.lblmonth.TabIndex = 586;
            this.lblmonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DateTimePicker2
            // 
            this.DateTimePicker2.Font = new System.Drawing.Font("Calibri", 12F);
            this.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DateTimePicker2.Location = new System.Drawing.Point(-4, 58);
            this.DateTimePicker2.Name = "DateTimePicker2";
            this.DateTimePicker2.Size = new System.Drawing.Size(100, 27);
            this.DateTimePicker2.TabIndex = 736;
            this.DateTimePicker2.Value = new System.DateTime(2013, 4, 28, 12, 0, 0, 0);
            // 
            // CheckBox1
            // 
            this.CheckBox1.Location = new System.Drawing.Point(173, 7);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(104, 24);
            this.CheckBox1.TabIndex = 1131;
            // 
            // DateTimePicker3
            // 
            this.DateTimePicker3.Font = new System.Drawing.Font("Calibri", 12F);
            this.DateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DateTimePicker3.Location = new System.Drawing.Point(-4, 86);
            this.DateTimePicker3.Name = "DateTimePicker3";
            this.DateTimePicker3.Size = new System.Drawing.Size(100, 27);
            this.DateTimePicker3.TabIndex = 737;
            this.DateTimePicker3.Value = new System.DateTime(2013, 4, 28, 13, 0, 0, 0);
            // 
            // txtto
            // 
            this.txtto.Font = new System.Drawing.Font("Calibri", 10F);
            this.txtto.Location = new System.Drawing.Point(-6, 28);
            this.txtto.Name = "txtto";
            this.txtto.Size = new System.Drawing.Size(88, 24);
            this.txtto.TabIndex = 747;
            // 
            // DateTimePicker6
            // 
            this.DateTimePicker6.Font = new System.Drawing.Font("Calibri", 12F);
            this.DateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DateTimePicker6.Location = new System.Drawing.Point(-4, 111);
            this.DateTimePicker6.Name = "DateTimePicker6";
            this.DateTimePicker6.Size = new System.Drawing.Size(100, 27);
            this.DateTimePicker6.TabIndex = 738;
            this.DateTimePicker6.Value = new System.DateTime(2013, 4, 28, 17, 0, 0, 0);
            // 
            // CheckBox2
            // 
            this.CheckBox2.AutoSize = true;
            this.CheckBox2.BackColor = System.Drawing.Color.Transparent;
            this.CheckBox2.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBox2.ForeColor = System.Drawing.Color.Black;
            this.CheckBox2.Location = new System.Drawing.Point(173, 30);
            this.CheckBox2.Name = "CheckBox2";
            this.CheckBox2.Size = new System.Drawing.Size(15, 14);
            this.CheckBox2.TabIndex = 745;
            this.CheckBox2.UseVisualStyleBackColor = false;
            // 
            // txtti
            // 
            this.txtti.Font = new System.Drawing.Font("Calibri", 10F);
            this.txtti.Location = new System.Drawing.Point(-6, 3);
            this.txtti.Name = "txtti";
            this.txtti.Size = new System.Drawing.Size(88, 24);
            this.txtti.TabIndex = 746;
            // 
            // DTPicker2
            // 
            this.DTPicker2.CustomFormat = "h:mm:ss tt";
            this.DTPicker2.Font = new System.Drawing.Font("Calibri", 10F);
            this.DTPicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DTPicker2.Location = new System.Drawing.Point(83, 28);
            this.DTPicker2.Name = "DTPicker2";
            this.DTPicker2.Size = new System.Drawing.Size(88, 24);
            this.DTPicker2.TabIndex = 748;
            this.DTPicker2.Value = new System.DateTime(2013, 4, 28, 17, 0, 0, 0);
            // 
            // txtmins
            // 
            this.txtmins.Font = new System.Drawing.Font("Calibri", 10F);
            this.txtmins.Location = new System.Drawing.Point(97, 86);
            this.txtmins.Name = "txtmins";
            this.txtmins.Size = new System.Drawing.Size(75, 24);
            this.txtmins.TabIndex = 742;
            // 
            // txthrs
            // 
            this.txthrs.Font = new System.Drawing.Font("Calibri", 10F);
            this.txthrs.Location = new System.Drawing.Point(97, 58);
            this.txthrs.Name = "txthrs";
            this.txthrs.Size = new System.Drawing.Size(75, 24);
            this.txthrs.TabIndex = 741;
            // 
            // DTPicker1
            // 
            this.DTPicker1.CustomFormat = "h:mm:ss tt";
            this.DTPicker1.Font = new System.Drawing.Font("Calibri", 10F);
            this.DTPicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DTPicker1.Location = new System.Drawing.Point(83, 3);
            this.DTPicker1.Name = "DTPicker1";
            this.DTPicker1.Size = new System.Drawing.Size(88, 24);
            this.DTPicker1.TabIndex = 749;
            this.DTPicker1.Value = new System.DateTime(2013, 4, 28, 8, 0, 0, 0);
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker7.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker7.Location = new System.Drawing.Point(0, 134);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(91, 20);
            this.dateTimePicker7.TabIndex = 762;
            this.dateTimePicker7.Value = new System.DateTime(2015, 4, 13, 15, 5, 0, 0);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.Navy;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(123, 506);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(245, 48);
            this.button1.TabIndex = 1135;
            this.button1.Text = "CLOCK IN";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblDate
            // 
            this.lblDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(67, 435);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(350, 16);
            this.lblDate.TabIndex = 1134;
            this.lblDate.Text = "label2";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTime
            // 
            this.lblTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTime.Font = new System.Drawing.Font("Courier New", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(67, 460);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(350, 41);
            this.lblTime.TabIndex = 1133;
            this.lblTime.Text = "00:00:00 AM";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.clockControl9);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.txtId);
            this.panel2.Controls.Add(this.lblStatus);
            this.panel2.Controls.Add(this.txtregNo);
            this.panel2.Controls.Add(this.lblDate);
            this.panel2.Controls.Add(this.imageBoxFrameGrabber);
            this.panel2.Controls.Add(this.lblregNo);
            this.panel2.Controls.Add(this.lblname);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.lblTime);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(664, 72);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(486, 621);
            this.panel2.TabIndex = 1135;
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(-66, 593);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(62, 20);
            this.txtId.TabIndex = 1137;
            // 
            // txtregNo
            // 
            this.txtregNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtregNo.Location = new System.Drawing.Point(-66, 557);
            this.txtregNo.MaxLength = 10;
            this.txtregNo.Name = "txtregNo";
            this.txtregNo.Size = new System.Drawing.Size(62, 30);
            this.txtregNo.TabIndex = 1136;
            this.txtregNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtregNo.TextChanged += new System.EventHandler(this.txtregNo_TextChanged);
            // 
            // imageBoxFrameGrabber
            // 
            this.imageBoxFrameGrabber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.imageBoxFrameGrabber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imageBoxFrameGrabber.Location = new System.Drawing.Point(74, 6);
            this.imageBoxFrameGrabber.Name = "imageBoxFrameGrabber";
            this.imageBoxFrameGrabber.Size = new System.Drawing.Size(350, 350);
            this.imageBoxFrameGrabber.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imageBoxFrameGrabber.TabIndex = 4;
            this.imageBoxFrameGrabber.TabStop = false;
            // 
            // lblregNo
            // 
            this.lblregNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblregNo.BackColor = System.Drawing.Color.Transparent;
            this.lblregNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblregNo.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblregNo.Location = new System.Drawing.Point(70, 358);
            this.lblregNo.Name = "lblregNo";
            this.lblregNo.Size = new System.Drawing.Size(351, 36);
            this.lblregNo.TabIndex = 1131;
            this.lblregNo.Text = "User Id";
            this.lblregNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblname
            // 
            this.lblname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblname.BackColor = System.Drawing.Color.Transparent;
            this.lblname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblname.ForeColor = System.Drawing.Color.Red;
            this.lblname.Location = new System.Drawing.Point(74, 392);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(351, 36);
            this.lblname.TabIndex = 1131;
            this.lblname.Text = "Name";
            this.lblname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // imageBox1
            // 
            this.imageBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.imageBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imageBox1.Location = new System.Drawing.Point(10, 74);
            this.imageBox1.Name = "imageBox1";
            this.imageBox1.Size = new System.Drawing.Size(19, 287);
            this.imageBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imageBox1.TabIndex = 1126;
            this.imageBox1.TabStop = false;
            // 
            // pic2
            // 
            this.pic2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pic2.Location = new System.Drawing.Point(453, 83);
            this.pic2.Name = "pic2";
            this.pic2.Size = new System.Drawing.Size(160, 160);
            this.pic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic2.TabIndex = 1120;
            this.pic2.TabStop = false;
            // 
            // LabelX1
            // 
            this.LabelX1.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.LabelX1.BackgroundStyle.BackColor = System.Drawing.Color.White;
            this.LabelX1.BackgroundStyle.BackColor2 = System.Drawing.Color.WhiteSmoke;
            this.LabelX1.BackgroundStyle.BackColorGradientAngle = 90;
            this.LabelX1.BackgroundStyle.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.LabelX1.BackgroundStyle.BorderBottomWidth = 3;
            this.LabelX1.BackgroundStyle.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(133)))), ((int)(((byte)(225)))));
            this.LabelX1.BackgroundStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.LabelX1.BackgroundStyle.BorderLeftWidth = 3;
            this.LabelX1.BackgroundStyle.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.LabelX1.BackgroundStyle.BorderRightWidth = 3;
            this.LabelX1.BackgroundStyle.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.LabelX1.BackgroundStyle.BorderTopWidth = 3;
            this.LabelX1.BackgroundStyle.Class = "";
            this.LabelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.LabelX1.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.LabelX1.Dock = System.Windows.Forms.DockStyle.Top;
            this.LabelX1.Font = new System.Drawing.Font("Cooper Black", 26.25F);
            this.LabelX1.ForeColor = System.Drawing.Color.Navy;
            this.LabelX1.Location = new System.Drawing.Point(0, 0);
            this.LabelX1.Name = "LabelX1";
            this.LabelX1.Size = new System.Drawing.Size(1150, 70);
            this.LabelX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.OfficeXP;
            this.LabelX1.TabIndex = 1119;
            this.LabelX1.Text = "FACE RECOGNITION";
            this.LabelX1.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // Panel3
            // 
            this.Panel3.Controls.Add(this.LabelX1);
            this.Panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel3.Location = new System.Drawing.Point(0, 0);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(1150, 72);
            this.Panel3.TabIndex = 1117;
            // 
            // clockControl9
            // 
            this.clockControl9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.clockControl9.BackColor = System.Drawing.Color.Transparent;
            this.clockControl9.ClockStyle = DevComponents.DotNetBar.Controls.eClockStyles.Custom;
            colorData1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData1.BrushAngle = 90F;
            colorData1.BrushSBSScale = 1F;
            colorData1.BrushType = DevComponents.DotNetBar.Controls.eBrushTypes.Linear;
            colorData1.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            colorData1.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            clockStyleData1.BezelColor = colorData1;
            colorData2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData2.BorderWidth = 0.01F;
            colorData2.BrushSBSScale = 1F;
            colorData2.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            colorData2.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            clockStyleData1.CapColor = colorData2;
            clockStyleData1.CapSize = 0.1F;
            colorData3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData3.BrushAngle = 90F;
            colorData3.BrushSBSScale = 1F;
            colorData3.BrushType = DevComponents.DotNetBar.Controls.eBrushTypes.Linear;
            colorData3.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
            colorData3.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            clockStyleData1.FaceColor = colorData3;
            clockStyleData1.GlassAngle = 0;
            colorData4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData4.BorderWidth = 0.01F;
            colorData4.BrushAngle = 90F;
            colorData4.BrushSBSScale = 1F;
            colorData4.BrushType = DevComponents.DotNetBar.Controls.eBrushTypes.Linear;
            colorData4.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData4.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            clockHandStyleData1.HandColor = colorData4;
            clockHandStyleData1.HandStyle = DevComponents.DotNetBar.Controls.eHandStyles.Style3;
            clockHandStyleData1.Length = 0.45F;
            clockHandStyleData1.Width = 0.175F;
            clockStyleData1.HourHandStyle = clockHandStyleData1;
            colorData5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData5.BorderWidth = 0.01F;
            colorData5.BrushSBSScale = 1F;
            colorData5.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData5.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            clockStyleData1.LargeTickColor = colorData5;
            clockStyleData1.LargeTickWidth = 0.01F;
            colorData6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData6.BorderWidth = 0.01F;
            colorData6.BrushAngle = 90F;
            colorData6.BrushSBSScale = 1F;
            colorData6.BrushType = DevComponents.DotNetBar.Controls.eBrushTypes.Linear;
            colorData6.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData6.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            clockHandStyleData2.HandColor = colorData6;
            clockHandStyleData2.HandStyle = DevComponents.DotNetBar.Controls.eHandStyles.Style3;
            clockHandStyleData2.Length = 0.75F;
            clockHandStyleData2.Width = 0.175F;
            clockStyleData1.MinuteHandStyle = clockHandStyleData2;
            clockStyleData1.NumberColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            clockStyleData1.NumberFont = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            clockHandStyleData3.DrawOverCap = true;
            colorData7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData7.BorderWidth = 0.01F;
            colorData7.BrushSBSScale = 1F;
            colorData7.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData7.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            clockHandStyleData3.HandColor = colorData7;
            clockHandStyleData3.HandStyle = DevComponents.DotNetBar.Controls.eHandStyles.Style4;
            clockHandStyleData3.Length = 0.9F;
            clockHandStyleData3.Width = 0.01F;
            clockStyleData1.SecondHandStyle = clockHandStyleData3;
            colorData8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData8.BorderWidth = 0.01F;
            colorData8.BrushSBSScale = 1F;
            colorData8.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            colorData8.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            clockStyleData1.SmallTickColor = colorData8;
            clockStyleData1.SmallTickLength = 0.01F;
            clockStyleData1.SmallTickWidth = 0.01F;
            clockStyleData1.Style = DevComponents.DotNetBar.Controls.eClockStyles.Custom;
            this.clockControl9.ClockStyleData = clockStyleData1;
            this.clockControl9.IndicatorStyle = DevComponents.DotNetBar.Controls.eClockIndicatorStyles.Numbers;
            this.clockControl9.IsEditable = true;
            this.clockControl9.Location = new System.Drawing.Point(383, 460);
            this.clockControl9.Name = "clockControl9";
            this.clockControl9.Size = new System.Drawing.Size(100, 100);
            this.clockControl9.TabIndex = 1136;
            this.clockControl9.Text = "clockControl9";
            this.clockControl9.TimeZone = null;
            this.clockControl9.Value = new System.DateTime(2011, 3, 8, 13, 32, 8, 266);
            // 
            // FaceDetect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 693);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.imageBox1);
            this.Controls.Add(this.Panel3);
            this.Name = "FaceDetect";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Face Recognition";
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgrv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageBoxFrameGrabber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).EndInit();
            this.Panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Emgu.CV.UI.ImageBox imageBoxFrameGrabber;
        internal System.Windows.Forms.Timer Timer3;
        private Emgu.CV.UI.ImageBox imageBox1;
        private System.Windows.Forms.Panel panel1;
        private DevComponents.DotNetBar.PanelEx PanelEx1;
        internal System.Windows.Forms.Label lblhour;
        internal System.Windows.Forms.Label lblday;
        internal System.Windows.Forms.Label lblyear;
        internal System.Windows.Forms.Label lblmonth;
        internal System.Windows.Forms.DateTimePicker DateTimePicker2;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.DateTimePicker DateTimePicker3;
        internal System.Windows.Forms.TextBox txtto;
        internal System.Windows.Forms.DateTimePicker DateTimePicker6;
        internal System.Windows.Forms.CheckBox CheckBox2;
        internal System.Windows.Forms.TextBox txtti;
        internal System.Windows.Forms.DateTimePicker DTPicker2;
        internal System.Windows.Forms.TextBox txtmins;
        internal System.Windows.Forms.TextBox txthrs;
        internal System.Windows.Forms.DateTimePicker DTPicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        internal System.Windows.Forms.PictureBox pic2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtId;
        internal System.Windows.Forms.Label lblname;
        internal System.Windows.Forms.TextBox txtregNo;
        private System.Windows.Forms.Timer timer1;
        internal System.Windows.Forms.Label lblregNo;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevComponents.DotNetBar.LabelX LabelX1;
        internal System.Windows.Forms.Panel Panel3;
        private System.Windows.Forms.DataGridView dgrv;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullname;
        private System.Windows.Forms.DataGridViewTextBoxColumn xdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn xtime;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
        private DevComponents.DotNetBar.Controls.AnalogClockControl clockControl9;
    }
}

