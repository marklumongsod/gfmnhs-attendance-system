﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic; 

namespace FaceRecognition
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        public MySqlDataAdapter da;
        public MySqlDataReader dr;
        public MySqlCommand cmd;


      

        private void LinkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
             
            String sq;
            String sa;
            String answer;
            String password;

            string username = Interaction.InputBox("Input your username ?", "Password Recovery", "", 500, 300); 
            if (username == "")
            {
                MessageBox.Show("You must enter a username to continue.");
                return;
            }
            else
            {
              config.connect();
             cmd = new MySqlCommand("SELECT * FROM tbl_users where username=@fd1 ", config.con);
             cmd.Parameters.AddWithValue("@fd1", username); 
            dr = cmd.ExecuteReader();
            if ((dr.Read())) //Data exist
            { 
                sq = (dr["sq"]).ToString();
                sa = (dr["sa"]).ToString();
                            password = (dr["password"]).ToString();  

                            answer =Interaction.InputBox(sq, "Enter your answer", "", 500, 300);   
                if (answer == sa)
                {
                    MessageBox.Show("Your password is : " + password, "Recovering password", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Wrong answer", "Invalid Answer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            } 
            else
            {
                MessageBox.Show("Username not valid", "Invalid Username", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            }
            }

                
        }

   
        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            int i=0;
            String userName, userType = "";

             config.connect();
             cmd = new MySqlCommand("SELECT *,CONCAT(fname, ' ' ,lname)fullname FROM tbl_users WHERE role='Admin' AND username=@fd1 AND password=@fd2", config.con);
            cmd.Parameters.AddWithValue("@fd1", txtun.Text);
            cmd.Parameters.AddWithValue("@fd2", txtup.Text);
            dr = cmd.ExecuteReader();
            if ((dr.Read())) //Data exist
            {

                config.user_id = (dr["id"]).ToString();
                userName = (dr["username"]).ToString();
                userType = (dr["role"]).ToString();
                MessageBox.Show("Welcome " + userType + " " + (dr["fullname"]).ToString(), "System", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (checkBox1.Checked)
                {
                    FaceDetect a = new FaceDetect();
                    a.Show();
                }
                else
                {
                    RegisterFace a = new RegisterFace();
                    a.Show();
                }


                txtun.Focus();
                this.Hide();
                 //a.lblUserName.Text = "Name : " + (dr["fullname"]).ToString();
                      //  a.lblusertype.Text = "Types : " + userType;
                     
                    
            }  else  {
            if (i == 3)
            { 
                MessageBox.Show("You have 3 attempt. The system will be close.", "Attempt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                System.Environment.Exit(0);
                return;
            } 
        MessageBox.Show("Invalid username or password","Login Failed",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
        i += 1;
    }
                
            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Close system?", "Closing", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                System.Windows.Forms.Application.Exit();
            }
            else
            {

            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            lbldt.Text =   DateTime.Now.ToLongDateString()  + " " +  DateTime.Now.ToString("h:mm:ss tt");  
        }

        public void btnenable()
        {
            if (txtun.Text == "" | txtup.Text == "")
            {
                btnLogin.Enabled = false;
            }
            else
            {
                btnLogin.Enabled = true;
            }
        }

        private void txtun_TextChanged(object sender, EventArgs e)
        {
            btnenable();
        }

        private void txtup_TextChanged(object sender, EventArgs e)
        {
            btnenable();
        }

        private void Login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin.PerformClick();
            }
            if (e.KeyCode == Keys.Escape)
            {
                btnClose.PerformClick();
            }
        }



      
       

     
 
    }
}
