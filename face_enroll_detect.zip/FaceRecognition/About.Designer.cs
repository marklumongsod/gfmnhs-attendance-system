﻿namespace FaceRecognition
{
    partial class About
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.txtWPMS = new System.Windows.Forms.TextBox();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.lblAllRightsReseved = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            this.GroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox1
            // 
            this.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GroupBox1.Controls.Add(this.PictureBox3);
            this.GroupBox1.Location = new System.Drawing.Point(8, 1);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(855, 351);
            this.GroupBox1.TabIndex = 2;
            this.GroupBox1.TabStop = false;
            // 
            // PictureBox3
            // 
            this.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureBox3.Location = new System.Drawing.Point(6, 11);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(843, 334);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox3.TabIndex = 2;
            this.PictureBox3.TabStop = false;
            // 
            // txtWPMS
            // 
            this.txtWPMS.BackColor = System.Drawing.Color.White;
            this.txtWPMS.Enabled = false;
            this.txtWPMS.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold);
            this.txtWPMS.ForeColor = System.Drawing.Color.Black;
            this.txtWPMS.Location = new System.Drawing.Point(8, 87);
            this.txtWPMS.Multiline = true;
            this.txtWPMS.Name = "txtWPMS";
            this.txtWPMS.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtWPMS.Size = new System.Drawing.Size(839, 97);
            this.txtWPMS.TabIndex = 0;
            this.txtWPMS.TabStop = false;
            this.txtWPMS.Text = "Face Recognition And License Plate Recognition System";
            // 
            // GroupBox2
            // 
            this.GroupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GroupBox2.Controls.Add(this.txtWPMS);
            this.GroupBox2.Controls.Add(this.lblAllRightsReseved);
            this.GroupBox2.Controls.Add(this.lblVersion);
            this.GroupBox2.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold);
            this.GroupBox2.ForeColor = System.Drawing.Color.White;
            this.GroupBox2.Location = new System.Drawing.Point(8, 358);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(855, 190);
            this.GroupBox2.TabIndex = 4;
            this.GroupBox2.TabStop = false;
            // 
            // lblAllRightsReseved
            // 
            this.lblAllRightsReseved.AutoSize = true;
            this.lblAllRightsReseved.Font = new System.Drawing.Font("Calibri", 15.25F, System.Drawing.FontStyle.Bold);
            this.lblAllRightsReseved.ForeColor = System.Drawing.Color.Black;
            this.lblAllRightsReseved.Location = new System.Drawing.Point(621, 58);
            this.lblAllRightsReseved.Name = "lblAllRightsReseved";
            this.lblAllRightsReseved.Size = new System.Drawing.Size(228, 26);
            this.lblAllRightsReseved.TabIndex = 5;
            this.lblAllRightsReseved.Text = "All Rights Reserved 2023";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Calibri", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.Color.Black;
            this.lblVersion.Location = new System.Drawing.Point(6, 36);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(125, 28);
            this.lblVersion.TabIndex = 4;
            this.lblVersion.Text = "Version: 1.0";
            // 
            // About
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 543);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.GroupBox2);
            this.Name = "About";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "About";
            this.GroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.TextBox txtWPMS;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Label lblAllRightsReseved;
        internal System.Windows.Forms.Label lblVersion;

    }
}