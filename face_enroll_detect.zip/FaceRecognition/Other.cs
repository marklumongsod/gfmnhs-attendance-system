﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FaceRecognition
{
    public partial class Other : Form
    {
        public Other()
        {
            InitializeComponent();
        }

        private void Other_Load(object sender, EventArgs e)
        {
            string connetionString = null;
            string server = "82.180.152.153";
            string database = "u916895930_webface";
            string username = "u916895930_webface";
            string password = "imBlessed@01"; 

            MySqlConnection cnn;
            connetionString = "SERVER=82.180.152.153;USER ID =u916895930_webface;PASSWORD=imBlessed@01;DATABASE=u916895930_webface;";
            cnn = new MySqlConnection(connetionString);
            try
            {
                cnn.Open();
                MessageBox.Show("Connection Open ! ");
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! " + ex.Message.ToString());
            }
        }
    }
}
