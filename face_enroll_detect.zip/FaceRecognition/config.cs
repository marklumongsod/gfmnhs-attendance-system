﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace FaceRecognition
{
    class config
    {
      
        public static string regNo; 
        public static string user_id;
        //public static string constring = "Server=localhost;" + "Database=faceplatedb;" + "Uid=root;" + "Password=;";
       //public static string constring = "Server=localhost;" + "Database=webfaceattendancedb;" + "Uid=root;" + "Password=;";
        public static string constring = "SERVER=srv616.hstgr.io; DATABASE=u916895930_webface;UID=u916895930_webface;PASSWORD=imBlessed@01;";
        
   // Public con As New MySqlConnection("SERVER=localhost;USER ID =root;PASSWORD=;DATABASE=mysqlDB") 'ito ginagamit ko dati
        
        public static MySqlDataAdapter da;
        public static MySqlDataReader dr;
        public static MySqlCommand cmd; 
         
        public static MySqlConnection con = new MySqlConnection(constring);

        public void setDgv(  System.Windows.Forms.DataGridView e)
        {
           // this.e.DefaultCellStyle.Font = new Font("Tahoma", 15);
            //this.e.DefaultCellStyle.ForeColor = Color.Blue;
            //this.e.DefaultCellStyle.BackColor = Color.Beige;
            //this.e.DefaultCellStyle.SelectionForeColor = Color.Yellow;
            //this.e.DefaultCellStyle.SelectionBackColor = Color.Black;
        }
 

        public void GridViewSettings(System.Windows.Forms.DataGridView x)
        {
          

            
        }

        public static void connect()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            else if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            else
            {
                con.Close();
                con.Open();
            }
        }
    }
}
